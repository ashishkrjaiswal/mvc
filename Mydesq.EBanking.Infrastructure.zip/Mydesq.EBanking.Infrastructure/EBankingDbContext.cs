using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Mydesq.Domain.Core;
using Mydesq.EBanking.Domain.Aggregates.OtpChallengeResponseAggregate;
using Mydesq.EBanking.Domain.Aggregates.TransactionAggregate;
using Mydesq.EBanking.Domain.Aggregates.UserAccessLogAggregate;
using Mydesq.EBanking.Domain.Aggregates.UserAggregate;
using Mydesq.EBanking.Domain.Aggregates.UserRegisteredDeviceAggregate;
using Mydesq.EBanking.Domain.Aggregates.UserRegistrationRequestAggregate;
using Mydesq.EBanking.Infrastructure.EntityConfigurations;
using Mydesq.Infrastructure.Core;

namespace Mydesq.EBanking.Infrastructure
{
    public class EBankingDbContext : DbContextBase, IUnitOfWork
    {
        public const string DEFAULT_SCHEMA = "dbo";

        public DbSet<User> Users { get; set; }
        public DbSet<UserCredential> UserCredentials { get; set; }
        public DbSet<UserSecFunctionalProfile> UserSecFunctionalProfiles { get; set; }
        public DbSet<UserRegistrationRequest> UserRegistrationRequests { get; set; }
        public DbSet<UserAccessLog> UserAccessLogs { get; set; }
        public DbSet<UserRegisteredDevice> UserRegisteredDevices { get; set; }
        public DbSet<OtpChallengeResponse> OtpChallengeResponses { get; set; }
        public DbSet<Transaction> Transactions { get; set; }

        public EBankingDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions, false)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new UserEntityConfiguration());
            modelBuilder.ApplyConfiguration(new UserCredentialEntityConfiguration());
            modelBuilder.ApplyConfiguration(new UserSecFunctionalProfileEntityConfiguration());
            modelBuilder.ApplyConfiguration(new UserRegistrationRequestEntityConfiguration());
            modelBuilder.ApplyConfiguration(new UserAccessLogEntityConfiguration());
            modelBuilder.ApplyConfiguration(new UserRegisteredDeviceEntityConfiguration());
            modelBuilder.ApplyConfiguration(new OtpChallengeResponseEntityConfiguration());

            modelBuilder.ApplyConfiguration(new TransactionEntityConfiguration());
        }
        public Task<bool> SaveEntitiesAsync(CancellationToken cancellationToken = default)
        {
            throw new System.NotImplementedException();
        }

    }
}
