using System;
using System.Threading.Tasks;
using Mydesq.Domain.Core;
using Mydesq.EBanking.Domain.Aggregates.UserRegistrationRequestAggregate;
using Microsoft.EntityFrameworkCore;

namespace Mydesq.EBanking.Infrastructure.Repositories
{
    public class UserRegistrationRequestRepository : IUserRegistrationRequestRepository
    {
        private readonly EBankingDbContext _context;
        public IUnitOfWork UnitOfWork => _context;

        public UserRegistrationRequestRepository(EBankingDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<UserRegistrationRequest> AddAsync(UserRegistrationRequest registrationRequest)
        {
            if (registrationRequest.IsTransient())
            {
                var requestSaved = await _context.UserRegistrationRequests.AddAsync(registrationRequest);
                return requestSaved.Entity;
            }
            else
            {
                return await Task.FromResult(registrationRequest);
            }
        }

        public async Task<UserRegistrationRequest> UpdateAsync(UserRegistrationRequest registrationRequest)
        {
            if (!registrationRequest.IsTransient())
            {
                var retVal = _context.UserRegistrationRequests.Update(registrationRequest).Entity;
                return await Task.FromResult(retVal);
            }
            else
            {
                return await Task.FromResult(registrationRequest);
            }
        }

        public async Task<UserRegistrationRequest> GetAsync(Guid id)
        {
            return await _context.UserRegistrationRequests.FindAsync(id);
        }
        public async Task<UserRegistrationRequest> GetAsync(string firstName,
            string lastName,
            string email,
            string mobileNr)
        {
            return await _context.UserRegistrationRequests
            .FirstOrDefaultAsync(x => x.FirstName == firstName
           && x.LastName == lastName
           && x.Email == email
           && x.MobileNr == mobileNr);
        }

    }
}