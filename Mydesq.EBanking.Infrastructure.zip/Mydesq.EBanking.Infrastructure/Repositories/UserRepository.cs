using System;
using System.Threading.Tasks;
using Mydesq.Domain.Core;
using Mydesq.EBanking.Domain.Aggregates.UserAggregate;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using Mydesq.API.Core.Security;

namespace Mydesq.EBanking.Infrastructure.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly EBankingDbContext _context;
        public IUnitOfWork UnitOfWork => _context;

        public UserRepository(EBankingDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<User> AddAsync(User user)
        {
            if (user.IsTransient())
            {
                user.InitializeId();
                var savedUser = await _context.Users.AddAsync(user);
                user.Credential.InitializeId();
                var savedCredential = await _context.UserCredentials.AddAsync(user.Credential);
                var savedFunctionalProfile = await _context.UserSecFunctionalProfiles.AddAsync(user.FunctionalProfile.FirstOrDefault());
                return savedUser.Entity;
            }
            else
            {
                return await Task.FromResult(user);
            }
        }

        public async Task<User> UpdateAsync(User user)
        {
            if (!user.IsTransient())
            {
                var retVal = _context.Users.Update(user).Entity;
                return await Task.FromResult(retVal);
            }
            else
            {
                return await Task.FromResult(user);
            }
        }
        public async Task<UserCredential> UpdateUserCredentialAsync(UserCredential userCredential)
        {
            if (!userCredential.IsTransient())
            {
                var retVal = _context.UserCredentials.Update(userCredential).Entity;
                return await Task.FromResult(retVal);
            }
            else
            {
                return await Task.FromResult(userCredential);
            }
        }

        public async Task<User> GetUserAsync(long userId)
        {
            return await _context.Users.FindAsync(userId);
        }

        public async Task<UserCredential> GetUserCredentialAsync(long userId)
        {
            return await _context.UserCredentials
                .FirstOrDefaultAsync(x => x.UserId == userId);
        }

        public async Task<User> GetUserAsync(string username)
        {
            var userCredential = await _context.UserCredentials
                .FirstOrDefaultAsync(x => x.Username == username);
            if (userCredential == null)
                return null;
                
            return await _context.Users.FindAsync(userCredential.UserId);
        }

        public async Task<long> GetNewUserIdAsync()
        {
            var maxUserId = await _context.Users.MaxAsync(u => (long?)u.Id);
            return (maxUserId ?? 0 + 1);
        }
        public async Task<long> GetNewUserCredentialIdAsync()
        {
            var maxUserCredentialId = await _context.UserCredentials.MaxAsync(u => (long?)u.Id);
            return (maxUserCredentialId ?? 0) + 1;
        }

        public async Task<bool> IsUserNameExistsAsync(string username)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(x => x.Email == username);
            return (user != null);
        }
        public async Task<UserCredential> GetUserCredentialAsync(string username)
        {
            return await _context.UserCredentials
                .FirstOrDefaultAsync(x => x.Username == username);
        }
        public async Task<UserSecFunctionalProfile> UpdateUserFunctionalProfileAsync(UserSecFunctionalProfile functionalProfile)
        {
            if (!functionalProfile.IsTransient())
            {
                var retVal = _context.UserSecFunctionalProfiles.Update(functionalProfile).Entity;
                return await Task.FromResult(retVal);
            }
            else
            {
                return await Task.FromResult(functionalProfile);
            }
        }
        
        public IEnumerable<UserSecFunctionalProfile> GetUserFunctionalProfileList(long userId)
        {
            return _context.UserSecFunctionalProfiles.Where(x => x.UserId == userId);
        }
        public IEnumerable<UserFunctionalProfile> GetUserFunctionalProfiles(long userId)
        {
            IEnumerable<UserFunctionalProfile> userFunctionalProfiles = null;
            if (userId != default)
            {
                var userSecFunctionalProfiles = GetUserFunctionalProfileList(userId);
                userFunctionalProfiles = userSecFunctionalProfiles.Select(x => new UserFunctionalProfile { FunctionalProfileId = x.FunctionalProfileId, IsSelected = x.IsSelected });
            }
            return userFunctionalProfiles;
        }

        public async Task<long> GetNewRecordIdAsync()
        {
            var maxNewRecordId = await _context.UserSecFunctionalProfiles.MaxAsync(u => (long?)u.RecordId);
            return (maxNewRecordId ?? 0) + 1;
        }
    }
}