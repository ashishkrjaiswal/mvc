using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Mydesq.Domain.Core;
using Mydesq.EBanking.Domain.Aggregates.OtpChallengeResponseAggregate;

namespace Mydesq.EBanking.Infrastructure.Repositories
{
    public class OtpChallengeResponseRepository : IOtpChallengeResponseRepository
    {
        private readonly EBankingDbContext _context;
        public IUnitOfWork UnitOfWork => _context;
        
        public OtpChallengeResponseRepository(EBankingDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<OtpChallengeResponse> AddAsync(OtpChallengeResponse challengeResponse)
        {
            if (challengeResponse.IsTransient())
            {
                var requestSaved = await _context.OtpChallengeResponses.AddAsync(challengeResponse);
                return requestSaved.Entity;
            }
            else
            {
                return await Task.FromResult(challengeResponse);
            }
        }
        public async Task<OtpChallengeResponse> UpdateAsync(OtpChallengeResponse challengeResponse)
        {
            if (!challengeResponse.IsTransient())
            {
                var retVal = _context.OtpChallengeResponses.Update(challengeResponse).Entity;
                return await Task.FromResult(retVal);
            }
            else
            {
                return await Task.FromResult(challengeResponse);
            }
        }
        public async Task<OtpChallengeResponse> GetAsync(Guid otpId)
        {
            return await _context.OtpChallengeResponses.FindAsync(otpId);
        }
    }
}