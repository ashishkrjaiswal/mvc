using System;
using System.Threading.Tasks;
using Mydesq.Domain.Core;
using Mydesq.EBanking.Domain.Aggregates.UserRegisteredDeviceAggregate;
using Microsoft.EntityFrameworkCore;

namespace Mydesq.EBanking.Infrastructure.Repositories
{
    public class UserRegisteredDeviceRepository : IUserRegisteredDeviceRepository
    {
        private readonly EBankingDbContext _context;
        public IUnitOfWork UnitOfWork => _context;

        public UserRegisteredDeviceRepository(EBankingDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<UserRegisteredDevice> AddAsync(UserRegisteredDevice registeredDevice)
        {
            if (registeredDevice.IsTransient())
            {
                var requestSaved = await _context.UserRegisteredDevices.AddAsync(registeredDevice);
                return requestSaved.Entity;
            }
            else
            {
                return await Task.FromResult(registeredDevice);
            }
        }
        public async Task<UserRegisteredDevice> UpdateAsync(UserRegisteredDevice registeredDevice)
        {
            if (!registeredDevice.IsTransient())
            {
                var retVal = _context.UserRegisteredDevices.Update(registeredDevice).Entity;
                return await Task.FromResult(retVal);
            }
            else
            {
                return await Task.FromResult(registeredDevice);
            }
        }
        public async Task<UserRegisteredDevice> GetAsync(long userId, string deviceIdentifier)
        {
            return await _context.UserRegisteredDevices.FirstOrDefaultAsync(d => d.UserId == userId && d.DeviceIdentifier == deviceIdentifier);
        }

    }
}