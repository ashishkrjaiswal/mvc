using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Mydesq.Domain.Core;
using Mydesq.EBanking.Domain.Aggregates.UserAccessLogAggregate;

namespace Mydesq.EBanking.Infrastructure.Repositories
{
    public class UserAccessLogRepository : IUserAccessLogRepository
    {
        private readonly EBankingDbContext _context;
        public IUnitOfWork UnitOfWork => _context;

        public UserAccessLogRepository(EBankingDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<UserAccessLog> AddAsync(UserAccessLog log)
        {
            if (log.IsTransient())
            {
                var savedUser = await _context.UserAccessLogs.AddAsync(log);
                return savedUser.Entity;
            }
            else
            {
                return await Task.FromResult(log);
            }
        }

        public async Task<UserAccessLog> UpdateAsync(UserAccessLog log)
        {
            if (!log.IsTransient())
            {
                var retVal = _context.UserAccessLogs.Update(log).Entity;
                return await Task.FromResult(retVal);
            }
            else
            {
                return await Task.FromResult(log);
            }
        }

        public async Task<UserAccessLog> GetUserAccessAsync(string loginTokenId)
        {
            return await _context
                .UserAccessLogs
                .FirstOrDefaultAsync(ua => ua.LoginTokenId == loginTokenId);
        }
    }
}