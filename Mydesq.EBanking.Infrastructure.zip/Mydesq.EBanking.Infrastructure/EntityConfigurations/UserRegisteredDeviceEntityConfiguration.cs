﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Mydesq.EBanking.Domain.Aggregates.UserRegisteredDeviceAggregate;
using Mydesq.Infrastructure.Core;

namespace Mydesq.EBanking.Infrastructure.EntityConfigurations
{
    public class UserRegisteredDeviceEntityConfiguration : EntityConfigurationBase<UserRegisteredDevice>
    {
        public override void Configure(EntityTypeBuilder<UserRegisteredDevice> configuration)
        {
            configuration.ToTable("usr_user_registered_device");

            configuration.HasKey(x => x.Id);

            configuration.Property(x => x.Id)
                .HasColumnName("device_id")
                .ValueGeneratedOnAdd();
            
            configuration.Property(x => x.UserId)
                .HasColumnName("user_id");

            configuration.Property(x => x.DeviceIdentifier)
                .HasColumnName("mydesq_device_identifier");
            
            configuration.Property(x => x.DeviceType)
                .HasColumnName("device_type");
            
            configuration.Property(x => x.DeviceOsVersion)
                .HasColumnName("device_os_version");
            
            configuration.Property(x => x.DeviceModel)
                .HasColumnName("device_model");

            configuration.Property(x => x.UseForOtp)
                .HasColumnName("use_for_otp");

            configuration.Property(x => x.EncapId)
                .HasColumnName("encap_id");
            
            configuration.Property(x => x.ActivationStartDate)
                .HasColumnName("activation_start_date");
            
            configuration.Property(x => x.ActivationEndDate)
                .HasColumnName("activation_end_date");
            
            configuration.Property(x => x.IsBlocked)
                .HasColumnName("is_blocked");
            
            configuration.Property(x => x.BlockingDate)
                .HasColumnName("blocking_date");
            
            configuration.Property(x => x.BlockingReason)
                .HasColumnName("blocking_reason");
            
            configuration.Property(x => x.KeyConfidentialData)
                .HasColumnName("key_confidential_data");
            
            configuration.Property(x => x.KeyNonConfidentialData)
                .HasColumnName("key_non_confidential_data");
            
            configuration.Property(x => x.NotificationDeviceIdentifier)
                .HasColumnName("notification_device_identifier");
            
            configuration.Property(x => x.ActiveFlag)
                .HasColumnName("active_flag");
        }
    }
}