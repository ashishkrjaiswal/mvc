﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Mydesq.EBanking.Domain.Aggregates.UserAggregate;
using Mydesq.Infrastructure.Core;

namespace Mydesq.EBanking.Infrastructure.EntityConfigurations
{
    public class UserCredentialEntityConfiguration : EntityConfigurationBase<UserCredential>
    {
        public override void Configure(EntityTypeBuilder<UserCredential> configuration)
        {
            configuration.ToTable("cfg_set_user_credential");

            configuration.HasKey(x => x.Id);
                
            configuration.Property(x => x.Id)
                .HasColumnName("credential_id");

            configuration.Property(x => x.SystemId)
                .HasColumnName("system_id");

            configuration.Property(x => x.UserId)
                .HasColumnName("user_id");

            configuration.Property(x => x.Username)
                .HasColumnName("username");

            configuration.Property(x => x.Password)
                .HasColumnName("password");

            configuration.Property(x => x.TempPassword)
                .HasColumnName("temp_password");

            configuration.Property(x => x.PasswordSalt)
                .HasColumnName("password_salt");

            configuration.Property(x => x.IsLocked)
                .HasColumnName("is_locked");

            configuration.Property(x => x.NoOfInvalidAttempt)
                .HasColumnName("no_of_invalid_attempt");

            configuration.Property(x => x.ExpiredTime)                  
                .HasColumnName("expired_time");

            configuration.Property(x => x.QuickbloxId)                  
                .HasColumnName("quickblox_id");
            
            configuration.Property(x => x.MarketmapGroup)                  
                .HasColumnName("marketmap_group");
            
            configuration.Property(x => x.TokenNr)                  
                .HasColumnName("token_nr");
            
            configuration.Property(x => x.NoLoginInUi)                  
                .HasColumnName("no_login_in_ui");

            configuration.Property(x => x.ExcludeTwoFactorAuth)
                .HasColumnName("exclude_two_factor_auth");

            configuration.Property(x => x.Otp)                  
                .HasColumnName("otp");
            
            configuration.Property(x => x.OtpExpiredTime)                  
                .HasColumnName("otp_expired_time");
        }
    }
}