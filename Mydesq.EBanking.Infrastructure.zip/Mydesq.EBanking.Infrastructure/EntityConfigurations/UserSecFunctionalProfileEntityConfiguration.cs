﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Mydesq.EBanking.Domain.Aggregates.UserAggregate;
using Mydesq.Infrastructure.Core;

namespace Mydesq.EBanking.Infrastructure.EntityConfigurations
{
    public class UserSecFunctionalProfileEntityConfiguration : EntityConfigurationBase<UserSecFunctionalProfile>
    {
        public override void Configure(EntityTypeBuilder<UserSecFunctionalProfile> configuration)
        {
            configuration.ToTable("usr_sec_functional_profile");

            configuration.Ignore(x => x.Id);

            configuration.HasKey(x => x.RecordId);

            configuration.Property(x => x.RecordId)
                .HasColumnName("record_id");

            configuration.Property(x => x.UserId)
                .HasColumnName("user_id");

            configuration.Property(x => x.FunctionalProfileId)
                .HasColumnName("functional_profile_id");

            configuration.Property(x => x.IsSelected)
                .HasColumnName("is_selected");
        }
    }
}