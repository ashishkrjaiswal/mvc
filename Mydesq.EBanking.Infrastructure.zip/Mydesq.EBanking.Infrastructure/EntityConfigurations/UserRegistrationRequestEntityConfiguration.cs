﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Mydesq.EBanking.Domain.Aggregates.UserRegistrationRequestAggregate;
using Mydesq.Infrastructure.Core;

namespace Mydesq.EBanking.Infrastructure.EntityConfigurations
{
    public class UserRegistrationRequestEntityConfiguration : EntityConfigurationBase<UserRegistrationRequest>
    {
        public override void Configure(EntityTypeBuilder<UserRegistrationRequest> configuration)
        {
            configuration.ToTable("ebk_usr_registration_request");

            configuration.HasKey(x => x.Id);

            configuration.Property(x => x.Id)
                .HasColumnName("tmp_user_id");

            configuration.Property(x => x.FirstName)
                .HasColumnName("first_name");

            configuration.Property(x => x.LastName)
                .HasColumnName("last_name");
            
            configuration.Property(x => x.Email)
                .HasColumnName("email");
            
            configuration.Property(x => x.MobileNr)
                .HasColumnName("mobile_nr");

            configuration.Property(x => x.Passsword)
                .HasColumnName("passsword");
            
            configuration.Property(x => x.PasswordSalt)                  
                .HasColumnName("password_salt");

            configuration.Property(x => x.RequestOriginIp)                  
                .HasColumnName("request_origin_ip");

            configuration.Property(x => x.RequestAgent)                  
                .HasColumnName("request_agent");

            configuration.Property(x => x.RequestDevice)                  
                .HasColumnName("request_device");

            configuration.Property(x => x.OtpSentHash)                  
                .HasColumnName("otp_sent_hash");

            configuration.Property(x => x.OtpValidUntil)                  
                .HasColumnName("otp_valid_until");

            configuration.Property(x => x.LastOtpSentOn)                  
                .HasColumnName("last_otp_sent_on");

            configuration.Property(x => x.LastOtpSentTo)                  
                .HasColumnName("last_otp_sent_to");

            configuration.Property(x => x.OtpCount)                  
                .HasColumnName("otp_count");

            configuration.Property(x => x.CorrectOtpReceived)                  
                .HasColumnName("correct_otp_received");
            
            configuration.Property(x => x.FinalUserId)                  
                .HasColumnName("final_user_id");

            configuration.Property(x => x.CreateTime)                  
                .HasColumnName("create_time");
        }
    }
}