﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Mydesq.EBanking.Domain.Aggregates.UserAccessLogAggregate;
using Mydesq.Infrastructure.Core;

namespace Mydesq.EBanking.Infrastructure.EntityConfigurations
{
    public class UserAccessLogEntityConfiguration : EntityConfigurationBase<UserAccessLog>
    {
        public override void Configure(EntityTypeBuilder<UserAccessLog> configuration)
        {
            configuration.ToTable("ebk_usr_access_log");

            configuration.HasKey(x => x.Id);
                
            configuration.Property(x => x.Id)
                .HasColumnName("record_id")
                .ValueGeneratedOnAdd();

            configuration.Property(x => x.UserId)
                .HasColumnName("user_id");

            configuration.Property(x => x.LoginTime)
                .HasColumnName("login_time");

            configuration.Property(x => x.LoginIpAddress)
                .HasColumnName("login_ip_address");

            configuration.Property(x => x.LoginDeviceId)
                .HasColumnName("login_device_id");

            configuration.Property(x => x.LoginDeviceType)
                .HasColumnName("login_device_type");

            configuration.Property(x => x.LoginLocation)
                .HasColumnName("login_location");

            configuration.Property(x => x.LoginTokenId)
                .HasColumnName("login_token_id");
            
            configuration.Property(x => x.LogOutTime)
                .HasColumnName("logOut_time");
        }
    }
}