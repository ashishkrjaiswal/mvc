using Mydesq.Infrastructure.Core;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Mydesq.EBanking.Domain.Aggregates.TransactionAggregate;

namespace Mydesq.EBanking.Infrastructure.EntityConfigurations
{
    public class TransactionEntityConfiguration : EntityConfigurationBase<Transaction>
    {
        public override void Configure(EntityTypeBuilder<Transaction> configuration)
        {
            configuration.ToTable("acc_portfolio_transaction");

            configuration.HasKey(x => x.Id)
                .HasName("transaction_id");

            configuration.Property(x => x.Amount)
                .HasColumnName("instrument_ccy")
                .HasColumnType("decimal(18,6)");

            configuration.Property(x => x.Date)
                .HasColumnName("trade_date");
                
            configuration.Property(x => x.Quantity)
                .HasColumnName("qty")
                .HasColumnType("decimal(10,2)");
        }
    }
}