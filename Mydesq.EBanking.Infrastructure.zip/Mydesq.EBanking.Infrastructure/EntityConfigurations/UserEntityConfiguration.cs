﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Mydesq.EBanking.Domain.Aggregates.UserAggregate;
using Mydesq.Infrastructure.Core;

namespace Mydesq.EBanking.Infrastructure.EntityConfigurations
{
    public class UserEntityConfiguration : EntityConfigurationBase<User>
    {
        public override void Configure(EntityTypeBuilder<User> configuration)
        {
            configuration.ToTable("cfg_set_user");

            configuration.HasKey(x => x.Id);
                
            configuration.Property(x => x.Id)
                .HasColumnName("user_id");

            configuration.Property(x => x.FirstName)
                .HasColumnName("firstname");

            configuration.Property(x => x.LastName)
                .HasColumnName("lastname");

            configuration.Property(x => x.CountryId)                  
                .HasColumnName("country_id");
            
            configuration.Property(x => x.Phone)                  
                .HasColumnName("phone");

            configuration.Property(x => x.Email)
                .HasColumnName("email");

            configuration.Property(x => x.Picture)                  
                .HasColumnName("picture");
            
            configuration.Property(x => x.DefaultTreeId)                  
                .HasColumnName("default_tree_id");

            configuration.Property(x => x.IsLocked)
                .HasColumnName("is_locked");

            configuration.Property(x => x.UserShort)                  
                .HasColumnName("user_short");

            configuration.Property(x => x.LanguageId)
                .HasColumnName("language_id");

            configuration.Property(x => x.ReportingToken)                  
                .HasColumnName("reporting_token");
            
            configuration.Property(x => x.Signature)                  
                .HasColumnName("signature");

            configuration.Property(x => x.BranchCode)                  
                .HasColumnName("branch_code");
            
            configuration.Property(x => x.DateFormat)                  
                .HasColumnName("date_format");
            
            configuration.Property(x => x.CurrencyFormat)                  
                .HasColumnName("currency_format");
            
            configuration.Property(x => x.NumberFormat)                  
                .HasColumnName("number_format");
            
            configuration.Property(x => x.LastConversationReadDate)                  
                .HasColumnName("last_conversation_read_date");
            
            configuration.Property(x => x.ContractNumber)                  
                .HasColumnName("ebk_contract_number");
            
            configuration.Property(x => x.OpenDate)                  
                .HasColumnName("ebk_open_date");
            
            configuration.Property(x => x.CloseDate)                  
                .HasColumnName("ebk_close_date");
            
            configuration.Property(x => x.ContractStatusId)                  
                .HasColumnName("ebk_contract_status_id");

            configuration.Property(x => x.Mobile)
                .HasColumnName("mobile");
        }
    }
}