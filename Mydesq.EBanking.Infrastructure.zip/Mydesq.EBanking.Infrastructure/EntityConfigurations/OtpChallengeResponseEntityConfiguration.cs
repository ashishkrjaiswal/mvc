﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Mydesq.EBanking.Domain.Aggregates.OtpChallengeResponseAggregate;
using Mydesq.Infrastructure.Core;

namespace Mydesq.EBanking.Infrastructure.EntityConfigurations
{
    public class OtpChallengeResponseEntityConfiguration : EntityConfigurationBase<OtpChallengeResponse>
    {
        public override void Configure(EntityTypeBuilder<OtpChallengeResponse> configuration)
        {
            configuration.ToTable("otp_challenge_response");

            configuration.Ignore(x => x.Id);
            
            configuration.HasKey(x => x.OtpId);

            configuration.Property(x => x.OtpId)
                .HasColumnName("otp_id");

            configuration.Property(x => x.OtpDestinationTypeId)                  
                .HasColumnName("otp_destination_type_id");
            
            configuration.Property(x => x.OtpDestinationDetail)                  
                .HasColumnName("otp_destination_detail");
            
            configuration.Property(x => x.OtpDateTimeSent)                  
                .HasColumnName("otp_date_time_sent");
            
            configuration.Property(x => x.OtpSent)                  
                .HasColumnName("otp_sent");
            
            configuration.Property(x => x.OtpExpiryTime)                  
                .HasColumnName("otp_expiry_time");
            
            configuration.Property(x => x.OtpDateTimeReceive)                  
                .HasColumnName("otp_date_time_receive");
            
            configuration.Property(x => x.OtpChannel)                  
                .HasColumnName("otp_channel");
            
            configuration.Property(x => x.OtpOriginIp)                  
                .HasColumnName("otp_origin_ip");
            
            configuration.Property(x => x.OtpLocation)                  
                .HasColumnName("otp_location");
            
            configuration.Property(x => x.OtpDeviceModel)                  
                .HasColumnName("otp_device_model");
            
            configuration.Property(x => x.OtpDeviceOsVersion)                  
                .HasColumnName("otp_device_os_version");
            
            configuration.Property(x => x.OtpWebBrowser)                  
                .HasColumnName("otp_web_browser");
            
            configuration.Property(x => x.OtpInvalidTry)                  
                .HasColumnName("otp_invalid_try");
            
            configuration.Property(x => x.OtpResponseStatusId)                  
                .HasColumnName("otp_response_status_id");
        }
    }
}